import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../api/axios";

export default function Attendance() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [subjects, setSubjects]   = useState([]);
  const [loading, setLoading]     = useState(true);
  const [toast, setToast]         = useState(null);
  const [showAdd, setShowAdd]     = useState(false);
  const [newSubject, setNewSubject] = useState("");
  const [adding, setAdding]       = useState(false);

  useEffect(() => {
    if (!user) return;
    fetchSubjects();
  }, [user]);

  const fetchSubjects = async () => {
    try {
      setLoading(true);
      const res = await api.get("/api/attendance");
      setSubjects(res.data);
    } catch { showToast("Failed to load", "error"); }
    finally { setLoading(false); }
  };

  const showToast = (msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  };

  const addSubject = async (e) => {
    e.preventDefault();
    if (!newSubject.trim()) return;
    try {
      setAdding(true);
      const res = await api.post("/api/attendance/subject", { name: newSubject.trim() });
      setSubjects(p => [...p, res.data]);
      setNewSubject("");
      setShowAdd(false);
      showToast("Subject added!");
    } catch (err) {
      showToast(err.response?.data?.message || "Failed", "error");
    } finally { setAdding(false); }
  };

  const markAttendance = async (subjectId, status) => {
    try {
      const res = await api.post(`/api/attendance/${subjectId}/mark`, { status });
      setSubjects(p => p.map(s => s._id === subjectId ? res.data : s));
      showToast(status === "present" ? "✅ Marked Present" : "❌ Marked Absent");
    } catch (err) {
      showToast(err.response?.data?.message || "Failed", "error");
    }
  };

  const deleteSubject = async (id) => {
    if (!window.confirm("Delete this subject?")) return;
    try {
      await api.delete(`/api/attendance/subject/${id}`);
      setSubjects(p => p.filter(s => s._id !== id));
      showToast("Deleted!");
    } catch { showToast("Failed", "error"); }
  };

  const getPercent = (s) => {
    const total = (s.present || 0) + (s.absent || 0);
    if (total === 0) return 0;
    return Math.round((s.present / total) * 100);
  };

  const getColor = (pct) => {
    if (pct >= 75) return "text-emerald-400";
    if (pct >= 60) return "text-amber-400";
    return "text-red-400";
  };

  const getBarColor = (pct) => {
    if (pct >= 75) return "bg-emerald-500";
    if (pct >= 60) return "bg-amber-500";
    return "bg-red-500";
  };

  const totalPresent = subjects.reduce((a, s) => a + (s.present || 0), 0);
  const totalAbsent  = subjects.reduce((a, s) => a + (s.absent || 0), 0);
  const totalClasses = totalPresent + totalAbsent;
  const overallPct   = totalClasses === 0 ? 0 : Math.round((totalPresent / totalClasses) * 100);

  if (!user) return (
    <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-6">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-10 text-center max-w-sm w-full">
        <div className="text-5xl mb-4">🔒</div>
        <h2 className="text-xl font-bold text-white mb-4">Login Required</h2>
        <button onClick={() => navigate("/login")}
          className="w-full bg-blue-500 text-white py-3 rounded-xl font-bold">Login →</button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-zinc-950">

      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl text-white text-sm font-semibold shadow-xl ${
          toast.type === "error" ? "bg-red-500" : "bg-emerald-500"
        }`}>{toast.msg}</div>
      )}

      {/* Add Subject Modal */}
      {showAdd && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-sm p-5">
            <h2 className="text-white font-black text-lg mb-4">Add Subject</h2>
            <form onSubmit={addSubject} className="space-y-3">
              <input
                autoFocus
                placeholder="Subject name e.g. Data Structures"
                value={newSubject}
                onChange={e => setNewSubject(e.target.value)}
                className="w-full bg-zinc-800 border border-zinc-700 text-white rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-blue-500"
              />
              <div className="flex gap-3">
                <button type="submit" disabled={adding || !newSubject.trim()}
                  className="flex-1 bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white py-3 rounded-xl font-bold text-sm transition-all">
                  {adding ? "Adding..." : "Add"}
                </button>
                <button type="button" onClick={() => { setShowAdd(false); setNewSubject(""); }}
                  className="px-5 py-3 bg-zinc-800 text-white rounded-xl text-sm">Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="max-w-2xl mx-auto px-4 py-6 pb-24">

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <button onClick={() => navigate("/")}
            className="w-10 h-10 bg-zinc-800 hover:bg-blue-500 text-white rounded-xl flex items-center justify-center font-bold text-lg transition-all flex-shrink-0">
            ‹
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-black text-white">Attendance</h1>
            <p className="text-zinc-500 text-xs">Track your class attendance</p>
          </div>
          <button onClick={() => setShowAdd(true)}
            className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-xl text-sm font-bold transition-all">
            + Subject
          </button>
        </div>

        {/* Overall Stats */}
        {subjects.length > 0 && (
          <div className="rounded-3xl p-5 mb-5 relative overflow-hidden"
            style={{ background: "linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%)", border: "1px solid #312e81" }}>
            <div className="flex items-center justify-between mb-3">
              <div>
                <p className="text-zinc-400 text-xs uppercase tracking-wider">Overall Attendance</p>
                <p className={`text-4xl font-black mt-1 ${getColor(overallPct)}`}>{overallPct}%</p>
              </div>
              <div className="text-right">
                <p className="text-zinc-400 text-xs">{totalPresent} Present</p>
                <p className="text-zinc-400 text-xs">{totalAbsent} Absent</p>
                <p className="text-zinc-400 text-xs">{totalClasses} Total</p>
              </div>
            </div>
            <div className="w-full bg-zinc-700 rounded-full h-2">
              <div className={`${getBarColor(overallPct)} h-2 rounded-full transition-all`}
                style={{ width: `${overallPct}%` }} />
            </div>
            <p className="text-zinc-500 text-xs mt-2">
              {overallPct >= 75 ? "✅ Good! Keep it up" : overallPct >= 60 ? "⚠️ Getting risky, attend more classes" : "❌ Critical! You may be detained"}
            </p>
          </div>
        )}

        {/* Subjects */}
        {loading ? (
          <div className="text-center py-16">
            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          </div>
        ) : subjects.length === 0 ? (
          <div className="text-center py-16 bg-zinc-900 border border-zinc-800 rounded-2xl">
            <p className="text-5xl mb-3">📚</p>
            <p className="text-white font-bold">No subjects yet</p>
            <p className="text-zinc-500 text-sm mt-1 mb-4">Add your subjects to start tracking</p>
            <button onClick={() => setShowAdd(true)}
              className="bg-blue-500 text-white px-6 py-2 rounded-xl font-bold text-sm">
              + Add Subject
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {subjects.map(s => {
              const pct = getPercent(s);
              const total = (s.present || 0) + (s.absent || 0);
              return (
                <div key={s._id} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-bold text-sm">{s.name}</p>
                      <p className="text-zinc-500 text-xs">{total} classes · {s.present || 0} present · {s.absent || 0} absent</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`text-lg font-black ${getColor(pct)}`}>{pct}%</span>
                      <button onClick={() => deleteSubject(s._id)}
                        className="text-zinc-700 hover:text-red-400 text-sm transition-all">🗑</button>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-zinc-800 rounded-full h-1.5 mb-3">
                    <div className={`${getBarColor(pct)} h-1.5 rounded-full transition-all`}
                      style={{ width: `${pct}%` }} />
                  </div>

                  {/* Mark buttons */}
                  <div className="flex gap-2">
                    <button onClick={() => markAttendance(s._id, "present")}
                      className="flex-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 border border-emerald-500/30 py-2 rounded-xl text-sm font-bold transition-all active:scale-95">
                      ✅ Present
                    </button>
                    <button onClick={() => markAttendance(s._id, "absent")}
                      className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-400 border border-red-500/30 py-2 rounded-xl text-sm font-bold transition-all active:scale-95">
                      ❌ Absent
                    </button>
                  </div>

                  {/* Warning */}
                  {pct < 75 && total > 0 && (
                    <p className="text-amber-400 text-xs mt-2 text-center">
                      {pct < 60
                        ? `⚠️ Need ${Math.ceil((0.75 * total - (s.present || 0)) / 0.25)} more classes to reach 75%`
                        : `⚠️ Attend next ${Math.ceil((0.75 * total - (s.present || 0)) / 0.25)} classes to be safe`}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}